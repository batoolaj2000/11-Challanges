import UIKit

func add_five(arr: [String]) -> [String] {
    return arr.map {$0 + "5"}
}

add_five(arr: ["6","Batool","8Hello"])




func middle_char(word: String) -> String {
    var middleChar = word.count/2
    var str = Array(word)
    return word.count % 2 == 0 ? "\(str[middleChar - 1])\(str[middleChar])":"\(str[middleChar])"
    }
    middle_char(word: "Batool")
    
    
    
    
func similarOrdered(word1: String, word2: String) -> String {
    var first = word1.sorted (by: {$0 < $1})
    var second = word2.sorted (by: {$0 < $1})
    var similar =  first.map { i in
        second.filter() { j in
            i == j
        }
    }
    var result : String = ""
    for i in 0..<similar.count {
        if !similar[i].isEmpty {
            result += String (similar[i][0])
            
        }else{
            break
        }
        
    }
    return result.count == 0 ? "No matches found" : "\(result)"
}

similarOrdered(word1: "Reem", word2: "Nouf")
